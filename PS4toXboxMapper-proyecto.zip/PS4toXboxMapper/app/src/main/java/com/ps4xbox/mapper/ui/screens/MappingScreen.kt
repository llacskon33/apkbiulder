package com.ps4xbox.mapper.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ps4xbox.mapper.core.MappingProfile
import com.ps4xbox.mapper.core.PsButton
import com.ps4xbox.mapper.core.XboxButton
import com.ps4xbox.mapper.data.FilterConfig
import com.ps4xbox.mapper.ui.components.AppCard
import com.ps4xbox.mapper.ui.components.BigButton
import com.ps4xbox.mapper.ui.components.ScreenTitle
import com.ps4xbox.mapper.ui.components.SectionLabel
import com.ps4xbox.mapper.ui.components.TogglePill
import com.ps4xbox.mapper.ui.theme.WarningAmber

@Composable
fun MappingScreen(
    profile: MappingProfile,
    filter: FilterConfig,
    serviceEnabled: Boolean,
    onMap: (PsButton, XboxButton) -> Unit,
    onReset: () -> Unit,
    onFilterEnabled: (Boolean) -> Unit,
    onToggleBlocked: (Int) -> Unit,
    onOpenAccessibility: () -> Unit,
) {
    val duplicates = profile.duplicates()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            ScreenTitle(
                "Equivalencias",
                "Elige a qué botón Xbox corresponde cada botón del DualShock 4.",
            )
        }

        if (duplicates.isNotEmpty()) {
            item {
                AppCard {
                    Text(
                        text = "Aviso: hay botones Xbox asignados a varios botones PS (" +
                            duplicates.keys.joinToString { it.label } + ").",
                        color = WarningAmber,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        }

        items(PsButton.entries, key = { it.name }) { ps ->
            MappingRow(
                ps = ps,
                current = profile.xboxFor(ps),
                onSelect = { onMap(ps, it) },
            )
        }

        item { BigButton("Restablecer equivalencias estándar", onReset, secondary = true) }

        item { FilterCard(filter, serviceEnabled, onFilterEnabled, onToggleBlocked, onOpenAccessibility) }
    }
}

@Composable
private fun MappingRow(ps: PsButton, current: XboxButton, onSelect: (XboxButton) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val changed = current != ps.defaultXbox

    AppCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = ps.label,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                text = if (changed) "editado  →" else "→",
                style = MaterialTheme.typography.bodyMedium,
                color = if (changed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.width(12.dp))
            Box {
                Button(
                    onClick = { expanded = true },
                    modifier = Modifier
                        .heightIn(min = 52.dp)
                        .widthIn(min = 128.dp),
                    shape = RoundedCornerShape(16.dp),
                ) {
                    Text(current.label, style = MaterialTheme.typography.titleMedium)
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    XboxButton.entries.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option.label) },
                            onClick = {
                                onSelect(option)
                                expanded = false
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FilterCard(
    filter: FilterConfig,
    serviceEnabled: Boolean,
    onFilterEnabled: (Boolean) -> Unit,
    onToggleBlocked: (Int) -> Unit,
    onOpenAccessibility: () -> Unit,
) {
    AppCard {
        SectionLabel("Filtro de botones (experimental)")
        Text(
            text = "Usa un servicio de accesibilidad que solo puede BLOQUEAR botones concretos para que no lleguen a la app en primer plano (por ejemplo StarParks). No puede convertirlos en otro botón ni crear un mando Xbox virtual.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Activar filtro",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium,
            )
            Switch(checked = filter.enabled, onCheckedChange = onFilterEnabled)
        }

        Text(
            text = if (serviceEnabled) "Servicio de accesibilidad: habilitado." else "Servicio de accesibilidad: NO habilitado.",
            style = MaterialTheme.typography.bodyMedium,
            color = if (serviceEnabled) MaterialTheme.colorScheme.primary else WarningAmber,
        )
        BigButton("Abrir ajustes de accesibilidad", onOpenAccessibility, secondary = true)

        Text(
            text = "Botones a bloquear:",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
        )
        PsButton.entries.filter { it.blockable }.chunked(3).forEach { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                rowItems.forEach { b ->
                    TogglePill(
                        text = b.label,
                        selected = b.reportedKeyCode in filter.blockedKeys,
                        onClick = { onToggleBlocked(b.reportedKeyCode) },
                        modifier = Modifier.weight(1f),
                    )
                }
                repeat(3 - rowItems.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}
