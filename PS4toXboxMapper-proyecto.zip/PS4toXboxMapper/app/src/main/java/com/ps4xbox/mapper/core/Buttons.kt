package com.ps4xbox.mapper.core

/**
 * Valores de `KeyEvent.KEYCODE_*` que usa la app.
 *
 * Se duplican aquí como constantes para que el paquete `core` sea Kotlin puro (sin dependencias de Android)
 * y se pueda probar en la JVM. Los valores coinciden con los de la API pública de Android.
 */
object AndroidKeys {
    const val DPAD_UP = 19
    const val DPAD_DOWN = 20
    const val DPAD_LEFT = 21
    const val DPAD_RIGHT = 22
    const val BUTTON_A = 96
    const val BUTTON_B = 97
    const val BUTTON_X = 99
    const val BUTTON_Y = 100
    const val BUTTON_L1 = 102
    const val BUTTON_R1 = 103
    const val BUTTON_L2 = 104
    const val BUTTON_R2 = 105
    const val BUTTON_THUMBL = 106
    const val BUTTON_THUMBR = 107
    const val BUTTON_START = 108
    const val BUTTON_SELECT = 109
    const val BUTTON_MODE = 110
    const val BUTTON_1 = 188
}

/** Botones del esquema Xbox y el `KeyEvent.KEYCODE_*` estándar de Android que les corresponde. */
enum class XboxButton(val label: String, val keyCode: Int?) {
    A("A", AndroidKeys.BUTTON_A),
    B("B", AndroidKeys.BUTTON_B),
    X("X", AndroidKeys.BUTTON_X),
    Y("Y", AndroidKeys.BUTTON_Y),
    LB("LB", AndroidKeys.BUTTON_L1),
    RB("RB", AndroidKeys.BUTTON_R1),
    LT("LT", AndroidKeys.BUTTON_L2),
    RT("RT", AndroidKeys.BUTTON_R2),
    LS("LS", AndroidKeys.BUTTON_THUMBL),
    RS("RS", AndroidKeys.BUTTON_THUMBR),
    MENU("MENU", AndroidKeys.BUTTON_START),
    VIEW("VIEW", AndroidKeys.BUTTON_SELECT),
    GUIDE("GUIDE", AndroidKeys.BUTTON_MODE),
    DPAD_UP("D-Pad ↑", AndroidKeys.DPAD_UP),
    DPAD_DOWN("D-Pad ↓", AndroidKeys.DPAD_DOWN),
    DPAD_LEFT("D-Pad ←", AndroidKeys.DPAD_LEFT),
    DPAD_RIGHT("D-Pad →", AndroidKeys.DPAD_RIGHT),
    NONE("Sin asignar", null),
}

/**
 * Botones del DualShock 4.
 *
 * [reportedKeyCode] es el código que Android informa para ese botón con el archivo de teclas estándar de AOSP
 * para el DualShock 4 (Cruz=BUTTON_A, Círculo=BUTTON_B, Cuadrado=BUTTON_X, Triángulo=BUTTON_Y,
 * SHARE=BUTTON_SELECT, OPTIONS=BUTTON_START, PS=BUTTON_MODE). Es decir, Android ya usa la
 * numeración "Xbox" por posición física.
 *
 * [blockable] indica si el botón puede bloquearse con el filtro de accesibilidad (solo botones de gamepad).
 */
enum class PsButton(
    val label: String,
    val reportedKeyCode: Int,
    val defaultXbox: XboxButton,
    val blockable: Boolean = true,
) {
    CROSS("X (Cruz)", AndroidKeys.BUTTON_A, XboxButton.A),
    CIRCLE("O (Círculo)", AndroidKeys.BUTTON_B, XboxButton.B),
    TRIANGLE("△ Triángulo", AndroidKeys.BUTTON_Y, XboxButton.Y),
    SQUARE("□ Cuadrado", AndroidKeys.BUTTON_X, XboxButton.X),
    L1("L1", AndroidKeys.BUTTON_L1, XboxButton.LB),
    R1("R1", AndroidKeys.BUTTON_R1, XboxButton.RB),
    L2("L2", AndroidKeys.BUTTON_L2, XboxButton.LT),
    R2("R2", AndroidKeys.BUTTON_R2, XboxButton.RT),
    L3("L3", AndroidKeys.BUTTON_THUMBL, XboxButton.LS),
    R3("R3", AndroidKeys.BUTTON_THUMBR, XboxButton.RS),
    OPTIONS("OPTIONS", AndroidKeys.BUTTON_START, XboxButton.MENU),
    SHARE("SHARE", AndroidKeys.BUTTON_SELECT, XboxButton.VIEW),
    PS("PS", AndroidKeys.BUTTON_MODE, XboxButton.GUIDE),
    TOUCHPAD("Touchpad (clic)", AndroidKeys.BUTTON_1, XboxButton.NONE),
    DPAD_UP("D-Pad ↑", AndroidKeys.DPAD_UP, XboxButton.DPAD_UP, blockable = false),
    DPAD_DOWN("D-Pad ↓", AndroidKeys.DPAD_DOWN, XboxButton.DPAD_DOWN, blockable = false),
    DPAD_LEFT("D-Pad ←", AndroidKeys.DPAD_LEFT, XboxButton.DPAD_LEFT, blockable = false),
    DPAD_RIGHT("D-Pad →", AndroidKeys.DPAD_RIGHT, XboxButton.DPAD_RIGHT, blockable = false);

    companion object {
        private val byKeyCode: Map<Int, PsButton> = entries.associateBy { it.reportedKeyCode }

        /** Identifica qué botón del DualShock 4 produjo un `keyCode` de Android, o `null` si no se reconoce. */
        fun fromKeyCode(keyCode: Int): PsButton? = byKeyCode[keyCode]
    }
}
