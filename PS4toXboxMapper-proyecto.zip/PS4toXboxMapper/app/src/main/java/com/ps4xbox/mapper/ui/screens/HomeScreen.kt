package com.ps4xbox.mapper.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ps4xbox.mapper.core.MappingProfile
import com.ps4xbox.mapper.data.FilterConfig
import com.ps4xbox.mapper.input.ControllerInfo
import com.ps4xbox.mapper.input.ControllerKind
import com.ps4xbox.mapper.ui.components.AppCard
import com.ps4xbox.mapper.ui.components.BigButton
import com.ps4xbox.mapper.ui.components.ScreenTitle
import com.ps4xbox.mapper.ui.components.SectionLabel
import com.ps4xbox.mapper.ui.components.StatusDot

@Composable
fun HomeScreen(
    controllers: List<ControllerInfo>,
    profile: MappingProfile,
    filter: FilterConfig,
    serviceEnabled: Boolean,
    onOpenTest: () -> Unit,
    onOpenMapping: () -> Unit,
) {
    val main = controllers.firstOrNull { it.kind == ControllerKind.DUALSHOCK4 } ?: controllers.firstOrNull()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { ScreenTitle("PS4 to Xbox Mapper", "Diagnóstico y equivalencias para tu mando") }

        item { StatusCard(main) }

        if (controllers.isNotEmpty()) {
            item { SectionLabel("Mandos detectados") }
            items(controllers, key = { it.deviceId }) { ControllerCard(it) }
        }

        item { BigButton("Abrir panel de pruebas", onOpenTest) }
        item { BigButton("Editar equivalencias", onOpenMapping, secondary = true) }

        item {
            AppCard {
                SectionLabel("Resumen")
                Text(
                    text = if (profile.changedCount() == 0) {
                        "Equivalencias: estándar PS → Xbox (sin cambios)."
                    } else {
                        "Equivalencias: ${profile.changedCount()} botón(es) modificado(s)."
                    },
                    style = MaterialTheme.typography.bodyLarge,
                )
                Text(
                    text = when {
                        !filter.enabled -> "Filtro de botones: desactivado."
                        serviceEnabled -> "Filtro de botones: activo (${filter.blockedKeys.size} botón(es) bloqueado(s))."
                        else -> "Filtro de botones: activado en la app, pero falta habilitar el servicio en Ajustes > Accesibilidad."
                    },
                    style = MaterialTheme.typography.bodyLarge,
                )
                Text(
                    text = "Las equivalencias se aplican dentro de esta app (panel de pruebas e informe). Android no permite que una app normal cambie lo que recibe StarParks; mira la pestaña Ayuda.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun StatusCard(main: ControllerInfo?) {
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(active = main != null)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    text = when {
                        main == null -> "Sin mando conectado"
                        main.kind == ControllerKind.DUALSHOCK4 -> "DualShock 4 conectado"
                        else -> "${main.kind.label} conectado"
                    },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = main?.name ?: "Empareja el mando por Bluetooth o conéctalo por USB (OTG).",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ControllerCard(c: ControllerInfo) {
    AppCard {
        Text(c.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text(
            "${c.kind.label} · VID %04X · PID %04X · id ${c.deviceId}".format(c.vendorId, c.productId),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            "Ejes: ${c.axisNames.joinToString(", ")}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
