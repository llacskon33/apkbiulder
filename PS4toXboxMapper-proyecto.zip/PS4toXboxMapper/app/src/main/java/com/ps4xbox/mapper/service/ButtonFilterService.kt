package com.ps4xbox.mapper.service

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.ps4xbox.mapper.data.FilterConfig
import com.ps4xbox.mapper.data.MappingRepository

/**
 * Filtro de botones (EXPERIMENTAL y opcional).
 *
 * Limitación real de Android: un AccessibilityService con `FLAG_REQUEST_FILTER_KEY_EVENTS` recibe los
 * eventos de tecla en [onKeyEvent] y solo puede responder "lo consumo" (true) o "déjalo pasar" (false).
 * NO puede inyectar, modificar ni reenviar eventos, así que esto no convierte el mando en un Xbox:
 * únicamente permite que ciertos botones elegidos por el usuario no lleguen a la app en primer plano.
 */
class ButtonFilterService : AccessibilityService() {

    private lateinit var repository: MappingRepository

    @Volatile
    private var config = FilterConfig()

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        config = repository.loadFilter()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        repository = MappingRepository(this)
        config = repository.loadFilter()
        repository.registerListener(prefsListener)
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val current = config
        if (!current.enabled || !KeyEvent.isGamepadButton(event.keyCode)) return false
        return event.keyCode in current.blockedKeys
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (::repository.isInitialized) repository.unregisterListener(prefsListener)
        super.onDestroy()
    }

    companion object {
        /** Indica si el usuario ha activado este servicio en Ajustes > Accesibilidad. */
        fun isEnabled(context: Context): Boolean {
            val component = ComponentName(context, ButtonFilterService::class.java)
            val enabled = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
            ) ?: return false
            return enabled.split(':').any { ComponentName.unflattenFromString(it) == component }
        }
    }
}
