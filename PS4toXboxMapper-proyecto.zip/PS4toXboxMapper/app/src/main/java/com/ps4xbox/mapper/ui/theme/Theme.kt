package com.ps4xbox.mapper.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val XboxGreen = Color(0xFF4ADE80)
val PsBlue = Color(0xFF5B8CFF)
val WarningAmber = Color(0xFFFBBF24)

private val DarkScheme = darkColorScheme(
    primary = XboxGreen,
    onPrimary = Color(0xFF05210F),
    secondary = PsBlue,
    onSecondary = Color.White,
    background = Color(0xFF0B0F1A),
    onBackground = Color(0xFFE6EAF2),
    surface = Color(0xFF121829),
    onSurface = Color(0xFFE6EAF2),
    surfaceVariant = Color(0xFF1B2338),
    onSurfaceVariant = Color(0xFFA9B3C9),
    outline = Color(0xFF3A4562),
    error = Color(0xFFFF6B6B),
)

/** Tema oscuro fijo de la app. */
@Composable
fun PS4XboxTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkScheme, content = content)
}
