package com.ps4xbox.mapper.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import com.ps4xbox.mapper.MainViewModel
import com.ps4xbox.mapper.ui.screens.HelpScreen
import com.ps4xbox.mapper.ui.screens.HomeScreen
import com.ps4xbox.mapper.ui.screens.MappingScreen
import com.ps4xbox.mapper.ui.screens.TestScreen

private enum class Tab(val title: String, val icon: ImageVector) {
    Home("Inicio", Icons.Filled.Home),
    Mapping("Equivalencias", Icons.Filled.Edit),
    Test("Pruebas", Icons.Filled.PlayArrow),
    Help("Ayuda", Icons.Filled.Info),
}

@Composable
fun AppRoot(viewModel: MainViewModel) {
    val context = LocalContext.current
    var tabIndex by rememberSaveable { mutableIntStateOf(0) }
    val tab = Tab.entries[tabIndex]

    val controllers by viewModel.controllers.collectAsState()
    val profile by viewModel.profile.collectAsState()
    val filter by viewModel.filter.collectAsState()
    val serviceEnabled by viewModel.serviceEnabled.collectAsState()
    val live by viewModel.live.collectAsState()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                Tab.entries.forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = index == tabIndex,
                        onClick = { tabIndex = index },
                        icon = { Icon(item.icon, contentDescription = item.title) },
                        label = { Text(item.title) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                            indicatorColor = MaterialTheme.colorScheme.primary,
                        ),
                    )
                }
            }
        },
    ) { innerPadding ->
        Box(Modifier.fillMaxSize().padding(innerPadding)) {
            AnimatedContent(
                targetState = tab,
                transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(150)) },
                label = "tabContent",
            ) { current ->
                when (current) {
                    Tab.Home -> HomeScreen(
                        controllers = controllers,
                        profile = profile,
                        filter = filter,
                        serviceEnabled = serviceEnabled,
                        onOpenTest = { tabIndex = Tab.Test.ordinal },
                        onOpenMapping = { tabIndex = Tab.Mapping.ordinal },
                    )

                    Tab.Mapping -> MappingScreen(
                        profile = profile,
                        filter = filter,
                        serviceEnabled = serviceEnabled,
                        onMap = viewModel::setMapping,
                        onReset = viewModel::resetMapping,
                        onFilterEnabled = viewModel::setFilterEnabled,
                        onToggleBlocked = viewModel::toggleBlocked,
                        onOpenAccessibility = {
                            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        },
                    )

                    Tab.Test -> TestScreen(
                        live = live,
                        controller = controllers.firstOrNull(),
                        onCapturing = viewModel::setCapturing,
                        onClear = viewModel::clearLive,
                        onShare = {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, viewModel.buildReport())
                            }
                            context.startActivity(Intent.createChooser(send, "Compartir informe"))
                        },
                    )

                    Tab.Help -> HelpScreen()
                }
            }
        }
    }
}
