package com.ps4xbox.mapper.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ps4xbox.mapper.ui.components.AppCard
import com.ps4xbox.mapper.ui.components.ScreenTitle
import com.ps4xbox.mapper.ui.components.SectionLabel

@Composable
fun HelpScreen() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { ScreenTitle("Ayuda y limitaciones", "Qué puede y qué no puede hacer Android sin root.") }

        item {
            HelpCard(
                "Qué hace esta app",
                "Detecta tu mando, muestra en tiempo real qué códigos de botón y qué ejes envía a Android, " +
                    "traduce cada botón PlayStation a su equivalente Xbox según tu perfil y genera un informe " +
                    "de diagnóstico que puedes compartir.",
            )
        }
        item {
            HelpCard(
                "Lo que Android ya hace por ti",
                "Android (desde la versión 9) identifica el DualShock 4 y lo trata con la numeración de un mando " +
                    "Xbox por posición: Cruz = A, Círculo = B, Cuadrado = X, Triángulo = Y, SHARE = SELECT, " +
                    "OPTIONS = START. Por eso tu tabla PS → Xbox coincide con lo que Android ya envía. Si en " +
                    "StarParks algo falla, el problema suele estar en cómo esa app interpreta los códigos o los " +
                    "ejes (por ejemplo los gatillos), no en la numeración.",
            )
        }
        item {
            HelpCard(
                "Lo que Android NO permite sin root",
                "• Crear un mando Xbox virtual global.\n" +
                    "• Cambiar los eventos que recibe otra app (StarParks).\n" +
                    "• Con un servicio de accesibilidad: solo se pueden observar y consumir eventos de tecla; " +
                    "no se pueden inyectar ni modificar. Por eso el filtro de botones solo bloquea, no convierte.\n" +
                    "• Sustituir el archivo de teclas del sistema (.kl) requiere root.",
            )
        }
        item {
            HelpCard(
                "Cómo diagnosticar un fallo en StarParks",
                "1. Abre el panel de pruebas y pulsa el botón que falla: apunta el código que llega.\n" +
                    "2. Mueve los sticks y aprieta L2/R2: comprueba que aparecen los ejes esperados.\n" +
                    "3. Repite conectando el mando por cable USB (OTG) y compara con Bluetooth.\n" +
                    "4. Revisa si StarParks tiene ajustes propios de mando o de mapeo de botones.\n" +
                    "5. Comparte el informe con el soporte de StarParks para que sepan qué envía tu mando.\n" +
                    "6. Si un botón concreto estorba, prueba el filtro de botones (experimental).",
            )
        }
        item {
            HelpCard(
                "Activar el filtro de accesibilidad",
                "Ajustes > Accesibilidad > PS4 to Xbox Mapper > activar. En Android 13, si la app se instaló " +
                    "desde un APK, el interruptor puede aparecer bloqueado: ve a Ajustes > Aplicaciones > " +
                    "PS4 to Xbox Mapper > ⋮ > «Permitir ajustes restringidos» y vuelve a intentarlo. " +
                    "El servicio no lee la pantalla ni recoge datos.",
            )
        }
    }
}

@Composable
private fun HelpCard(title: String, body: String) {
    AppCard {
        SectionLabel(title)
        Text(body, style = MaterialTheme.typography.bodyMedium)
    }
}
