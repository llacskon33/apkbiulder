package com.ps4xbox.mapper.ui.screens

import android.view.KeyEvent
import android.view.MotionEvent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ps4xbox.mapper.input.ControllerInfo
import com.ps4xbox.mapper.input.KeyRecord
import com.ps4xbox.mapper.input.LiveInput
import com.ps4xbox.mapper.ui.components.AppCard
import com.ps4xbox.mapper.ui.components.BigButton
import com.ps4xbox.mapper.ui.components.ScreenTitle
import com.ps4xbox.mapper.ui.components.SectionLabel
import kotlin.math.max

@Composable
fun TestScreen(
    live: LiveInput,
    controller: ControllerInfo?,
    onCapturing: (Boolean) -> Unit,
    onClear: () -> Unit,
    onShare: () -> Unit,
) {
    // Mientras este panel está visible, la Activity consume los eventos del mando (no mueven el foco de la UI).
    DisposableEffect(Unit) {
        onCapturing(true)
        onDispose { onCapturing(false) }
    }

    val axes = live.axes
    fun axis(id: Int): Float = axes[id] ?: 0f

    val leftX = axis(MotionEvent.AXIS_X)
    val leftY = axis(MotionEvent.AXIS_Y)
    // Android usa Z/RZ para el stick derecho de DualShock 4 y de los mandos Xbox; algunos mandos usan RX/RY.
    val rightX = if (axes.containsKey(MotionEvent.AXIS_Z)) axis(MotionEvent.AXIS_Z) else axis(MotionEvent.AXIS_RX)
    val rightY = if (axes.containsKey(MotionEvent.AXIS_RZ)) axis(MotionEvent.AXIS_RZ) else axis(MotionEvent.AXIS_RY)
    val leftTrigger = max(axis(MotionEvent.AXIS_LTRIGGER), axis(MotionEvent.AXIS_BRAKE))
    val rightTrigger = max(axis(MotionEvent.AXIS_RTRIGGER), axis(MotionEvent.AXIS_GAS))

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { ScreenTitle("Panel de pruebas", "Pulsa botones y mueve sticks y gatillos del mando.") }

        item {
            AppCard {
                Text(
                    text = controller?.let { "${it.kind.label}: ${it.name}" }
                        ?: "No hay mando conectado. Empareja el DualShock 4 y vuelve aquí.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (controller != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        item { LastKeyCard(live.log.firstOrNull { it.down }) }

        item {
            AppCard {
                SectionLabel("Pulsados ahora")
                if (live.pressed.isEmpty()) {
                    Text("Ninguno", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        live.pressed.sorted().forEach { code ->
                            Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primary) {
                                Text(
                                    text = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_"),
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    style = MaterialTheme.typography.labelLarge,
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            AppCard {
                SectionLabel("Joysticks")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    StickView("Stick izquierdo", leftX, leftY)
                    StickView("Stick derecho", rightX, rightY)
                }
            }
        }

        item {
            AppCard {
                SectionLabel("Gatillos analógicos")
                TriggerBar("L2 → LT", leftTrigger)
                TriggerBar("R2 → RT", rightTrigger)
            }
        }

        item {
            AppCard {
                SectionLabel("Ejes en bruto")
                if (axes.isEmpty()) {
                    Text(
                        "Mueve un stick o aprieta un gatillo para ver los ejes.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    axes.toSortedMap().forEach { (axisId, value) ->
                        Text(
                            text = "${MotionEvent.axisToString(axisId)}  =  %.2f".format(value),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }
        }

        item { SectionLabel("Últimos eventos") }
        if (live.log.isEmpty()) {
            item { Text("Aún no se ha recibido ningún botón.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        items(live.log.take(12), key = { it.id }) { LogRow(it) }

        item { BigButton("Compartir informe de diagnóstico", onShare) }
        item { BigButton("Limpiar", onClear, secondary = true) }
    }
}

@Composable
private fun LastKeyCard(record: KeyRecord?) {
    AppCard {
        SectionLabel("Último botón detectado")
        if (record == null) {
            Text(
                "Pulsa cualquier botón del mando.",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            Text(
                text = record.keyName,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
            )
            Text("Código de Android: ${record.keyCode}", style = MaterialTheme.typography.bodyLarge)
            val t = record.translation
            Text(
                text = if (t != null) {
                    "${t.ps.label}  →  Xbox ${t.xbox.label}" + (t.outputKeyCode?.let { " (código $it)" } ?: "")
                } else {
                    "Botón no reconocido como parte del DualShock 4"
                },
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
private fun LogRow(record: KeyRecord) {
    Column {
        Text(
            text = (if (record.down) "▼ " else "▲ ") + "${record.keyName} (${record.keyCode})",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
        )
        val t = record.translation
        Text(
            text = if (t != null) "${t.ps.label} → Xbox ${t.xbox.label}" else "no reconocido",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun TriggerBar(label: String, value: Float) {
    val animated by animateFloatAsState(
        targetValue = value.coerceIn(0f, 1f),
        animationSpec = tween(80),
        label = "trigger",
    )
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            Text("%.2f".format(value), style = MaterialTheme.typography.bodyLarge)
        }
        LinearProgressIndicator(
            progress = { animated },
            modifier = Modifier
                .fillMaxWidth()
                .height(12.dp),
            strokeCap = StrokeCap.Round,
        )
    }
}

@Composable
private fun StickView(label: String, x: Float, y: Float) {
    val ring = MaterialTheme.colorScheme.outline
    val dot = MaterialTheme.colorScheme.primary
    val ax by animateFloatAsState(x.coerceIn(-1f, 1f), tween(60), label = "stickX")
    val ay by animateFloatAsState(y.coerceIn(-1f, 1f), tween(60), label = "stickY")

    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Canvas(modifier = Modifier.size(130.dp)) {
            val radius = size.minDimension / 2f
            val knob = 14.dp.toPx()
            drawCircle(color = ring, radius = radius, style = Stroke(width = 3.dp.toPx()))
            drawLine(ring.copy(alpha = 0.5f), Offset(center.x - radius, center.y), Offset(center.x + radius, center.y), 1.dp.toPx())
            drawLine(ring.copy(alpha = 0.5f), Offset(center.x, center.y - radius), Offset(center.x, center.y + radius), 1.dp.toPx())
            val travel = radius - knob
            drawCircle(
                color = dot,
                radius = knob,
                center = Offset(center.x + ax * travel, center.y + ay * travel),
            )
        }
        Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
        Text(
            "X %.2f   Y %.2f".format(x, y),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
