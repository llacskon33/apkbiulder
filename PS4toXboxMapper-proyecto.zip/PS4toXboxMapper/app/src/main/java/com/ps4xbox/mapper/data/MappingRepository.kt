package com.ps4xbox.mapper.data

import android.content.Context
import android.content.SharedPreferences
import com.ps4xbox.mapper.core.MappingCodec
import com.ps4xbox.mapper.core.MappingProfile

/** Configuración del filtro de botones (servicio de accesibilidad opcional). */
data class FilterConfig(
    val enabled: Boolean = false,
    /** Códigos `KeyEvent.KEYCODE_*` de botones de gamepad que el servicio debe consumir. */
    val blockedKeys: Set<Int> = emptySet(),
)

/** Persistencia local (SharedPreferences) del perfil de equivalencias y del filtro. */
class MappingRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun loadProfile(): MappingProfile = MappingCodec.decode(prefs.getString(KEY_PROFILE, null))

    fun saveProfile(profile: MappingProfile) {
        prefs.edit().putString(KEY_PROFILE, MappingCodec.encode(profile)).apply()
    }

    fun loadFilter(): FilterConfig {
        val blocked = prefs.getString(KEY_BLOCKED, "").orEmpty()
            .split(',')
            .mapNotNull { it.trim().toIntOrNull() }
            .toSet()
        return FilterConfig(enabled = prefs.getBoolean(KEY_FILTER_ON, false), blockedKeys = blocked)
    }

    fun saveFilter(config: FilterConfig) {
        prefs.edit()
            .putBoolean(KEY_FILTER_ON, config.enabled)
            .putString(KEY_BLOCKED, config.blockedKeys.joinToString(","))
            .apply()
    }

    fun registerListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun unregisterListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
    }

    private companion object {
        const val PREFS = "ps4xbox_prefs"
        const val KEY_PROFILE = "profile"
        const val KEY_FILTER_ON = "filter_enabled"
        const val KEY_BLOCKED = "filter_blocked_keys"
    }
}
