package com.ps4xbox.mapper.input

import com.ps4xbox.mapper.core.Translation

/** Un evento de botón recibido del mando. */
data class KeyRecord(
    val id: Long,
    val deviceId: Int,
    val keyCode: Int,
    /** Nombre de Android sin el prefijo `KEYCODE_` (p. ej. `BUTTON_A`). */
    val keyName: String,
    val down: Boolean,
    val translation: Translation?,
)

/** Estado en vivo del mando para el panel de pruebas. */
data class LiveInput(
    val pressed: Set<Int> = emptySet(),
    /** Valor actual de cada eje (`MotionEvent.AXIS_*`) visto en el mando. */
    val axes: Map<Int, Float> = emptyMap(),
    /** Eventos recientes, el más nuevo primero. */
    val log: List<KeyRecord> = emptyList(),
)
