package com.ps4xbox.mapper.input

import android.content.Context
import android.hardware.input.InputManager
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import android.view.MotionEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ControllerKind(val label: String) {
    DUALSHOCK4("DualShock 4"),
    DUALSENSE("DualSense"),
    XBOX("Mando Xbox"),
    OTHER("Mando genérico"),
}

/** Datos de un mando detectado por Android. */
data class ControllerInfo(
    val deviceId: Int,
    val name: String,
    val vendorId: Int,
    val productId: Int,
    val kind: ControllerKind,
    val sources: Int,
    /** Ejes (`MotionEvent.AXIS_*`) que el mando declara a Android. */
    val axes: List<Int>,
) {
    val axisNames: List<String>
        get() = axes.map { MotionEvent.axisToString(it).removePrefix("AXIS_") }
}

/**
 * Detecta mandos conectados con la API pública `InputManager` / `InputDevice`
 * y se entera de altas y bajas mediante `InputManager.InputDeviceListener`.
 */
class ControllerMonitor(context: Context) : InputManager.InputDeviceListener {

    private val inputManager = context.applicationContext.getSystemService(Context.INPUT_SERVICE) as InputManager

    private val _controllers = MutableStateFlow<List<ControllerInfo>>(emptyList())
    val controllers: StateFlow<List<ControllerInfo>> = _controllers.asStateFlow()

    fun start() {
        inputManager.registerInputDeviceListener(this, Handler(Looper.getMainLooper()))
        refresh()
    }

    fun stop() {
        inputManager.unregisterInputDeviceListener(this)
    }

    fun refresh() {
        _controllers.value = InputDevice.getDeviceIds()
            .mapNotNull { InputDevice.getDevice(it) }
            .filter { isGameController(it) }
            .map { toInfo(it) }
    }

    override fun onInputDeviceAdded(deviceId: Int) = refresh()
    override fun onInputDeviceRemoved(deviceId: Int) = refresh()
    override fun onInputDeviceChanged(deviceId: Int) = refresh()

    private fun isGameController(device: InputDevice): Boolean {
        if (device.isVirtual) return false
        val s = device.sources
        return (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
    }

    private fun toInfo(device: InputDevice) = ControllerInfo(
        deviceId = device.id,
        name = device.name ?: "Mando",
        vendorId = device.vendorId,
        productId = device.productId,
        kind = classify(device),
        sources = device.sources,
        axes = device.motionRanges.map { it.axis }.sorted(),
    )

    private fun classify(device: InputDevice): ControllerKind = when {
        device.vendorId == VENDOR_SONY && device.productId in DS4_PRODUCT_IDS -> ControllerKind.DUALSHOCK4
        device.vendorId == VENDOR_SONY && device.productId in DUALSENSE_PRODUCT_IDS -> ControllerKind.DUALSENSE
        device.vendorId == VENDOR_MICROSOFT -> ControllerKind.XBOX
        // Respaldo: Android suele llamar "Wireless Controller" al DualShock 4.
        device.vendorId == VENDOR_SONY && device.name?.contains("Wireless Controller", ignoreCase = true) == true ->
            ControllerKind.DUALSHOCK4
        else -> ControllerKind.OTHER
    }

    private companion object {
        const val VENDOR_SONY = 0x054c
        const val VENDOR_MICROSOFT = 0x045e
        // DualShock 4 v1, v2 y adaptador USB inalámbrico de Sony.
        val DS4_PRODUCT_IDS = setOf(0x05c4, 0x09cc, 0x0ba0)
        // DualSense y DualSense Edge.
        val DUALSENSE_PRODUCT_IDS = setOf(0x0ce6, 0x0df2)
    }
}
