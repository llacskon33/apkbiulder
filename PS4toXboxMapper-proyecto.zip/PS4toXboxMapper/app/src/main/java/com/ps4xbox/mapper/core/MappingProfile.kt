package com.ps4xbox.mapper.core

/** Resultado de traducir un botón del mando: qué botón PS es, a qué botón Xbox se asigna y su código de Android. */
data class Translation(
    val ps: PsButton,
    val xbox: XboxButton,
    val outputKeyCode: Int?,
)

/** Perfil editable de equivalencias PlayStation → Xbox. Inmutable: cada cambio devuelve un perfil nuevo. */
data class MappingProfile(val entries: Map<PsButton, XboxButton>) {

    fun xboxFor(ps: PsButton): XboxButton = entries[ps] ?: ps.defaultXbox

    fun withMapping(ps: PsButton, xbox: XboxButton): MappingProfile =
        MappingProfile(entries + (ps to xbox))

    /** Traduce un `keyCode` de Android recibido del mando. Devuelve `null` si el botón no es reconocido. */
    fun translate(keyCode: Int): Translation? {
        val ps = PsButton.fromKeyCode(keyCode) ?: return null
        val xbox = xboxFor(ps)
        return Translation(ps, xbox, xbox.keyCode)
    }

    /** Número de botones cuya equivalencia difiere de la estándar. */
    fun changedCount(): Int = PsButton.entries.count { xboxFor(it) != it.defaultXbox }

    /** Botones Xbox asignados a más de un botón PS (suele indicar un error de configuración). */
    fun duplicates(): Map<XboxButton, List<PsButton>> =
        PsButton.entries
            .filter { xboxFor(it) != XboxButton.NONE }
            .groupBy { xboxFor(it) }
            .filterValues { it.size > 1 }

    companion object {
        val DEFAULT = MappingProfile(PsButton.entries.associateWith { it.defaultXbox })
    }
}

/** Serialización a texto simple (`CROSS=A`, una línea por botón). Tolerante a líneas desconocidas o ausentes. */
object MappingCodec {
    fun encode(profile: MappingProfile): String =
        PsButton.entries.joinToString("\n") { "${it.name}=${profile.xboxFor(it).name}" }

    fun decode(text: String?): MappingProfile {
        if (text.isNullOrBlank()) return MappingProfile.DEFAULT
        val parsed = HashMap<PsButton, XboxButton>()
        for (line in text.lineSequence()) {
            val parts = line.split('=', limit = 2)
            if (parts.size != 2) continue
            val ps = PsButton.entries.firstOrNull { it.name == parts[0].trim() } ?: continue
            val xbox = XboxButton.entries.firstOrNull { it.name == parts[1].trim() } ?: continue
            parsed[ps] = xbox
        }
        return MappingProfile(MappingProfile.DEFAULT.entries + parsed)
    }
}
