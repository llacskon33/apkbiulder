package com.ps4xbox.mapper

import android.app.Application
import android.os.Build
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.lifecycle.AndroidViewModel
import com.ps4xbox.mapper.core.MappingProfile
import com.ps4xbox.mapper.core.PsButton
import com.ps4xbox.mapper.core.XboxButton
import com.ps4xbox.mapper.data.FilterConfig
import com.ps4xbox.mapper.data.MappingRepository
import com.ps4xbox.mapper.input.ControllerInfo
import com.ps4xbox.mapper.input.ControllerMonitor
import com.ps4xbox.mapper.input.KeyRecord
import com.ps4xbox.mapper.input.LiveInput
import com.ps4xbox.mapper.service.ButtonFilterService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MappingRepository(application)
    private val monitor = ControllerMonitor(application)

    val controllers: StateFlow<List<ControllerInfo>> = monitor.controllers

    private val _profile = MutableStateFlow(repository.loadProfile())
    val profile: StateFlow<MappingProfile> = _profile.asStateFlow()

    private val _filter = MutableStateFlow(repository.loadFilter())
    val filter: StateFlow<FilterConfig> = _filter.asStateFlow()

    private val _serviceEnabled = MutableStateFlow(false)
    val serviceEnabled: StateFlow<Boolean> = _serviceEnabled.asStateFlow()

    private val _live = MutableStateFlow(LiveInput())
    val live: StateFlow<LiveInput> = _live.asStateFlow()

    private var captureCount = 0
    private var nextId = 0L

    /** `true` mientras el panel de pruebas está visible: la Activity consume los eventos del mando. */
    val capturing: Boolean get() = captureCount > 0

    init {
        monitor.start()
        refreshStatus()
    }

    override fun onCleared() {
        monitor.stop()
    }

    fun refreshStatus() {
        monitor.refresh()
        _serviceEnabled.value = ButtonFilterService.isEnabled(getApplication())
    }

    fun setCapturing(on: Boolean) {
        captureCount = (captureCount + if (on) 1 else -1).coerceAtLeast(0)
    }

    // ---- Eventos del mando (llamados desde MainActivity) ----

    fun onKeyEvent(event: KeyEvent) {
        val down = when (event.action) {
            KeyEvent.ACTION_DOWN -> true
            KeyEvent.ACTION_UP -> false
            else -> return
        }
        if (down && event.repeatCount > 0) return
        val record = KeyRecord(
            id = nextId++,
            deviceId = event.deviceId,
            keyCode = event.keyCode,
            keyName = KeyEvent.keyCodeToString(event.keyCode).removePrefix("KEYCODE_"),
            down = down,
            translation = _profile.value.translate(event.keyCode),
        )
        _live.update { cur ->
            cur.copy(
                pressed = if (down) cur.pressed + event.keyCode else cur.pressed - event.keyCode,
                log = (listOf(record) + cur.log).take(MAX_LOG),
            )
        }
    }

    fun onMotion(event: MotionEvent) {
        val device = event.device ?: return
        val values = HashMap<Int, Float>()
        for (range in device.motionRanges) {
            values[range.axis] = event.getAxisValue(range.axis)
        }
        _live.update { it.copy(axes = it.axes + values) }
    }

    fun clearLive() {
        _live.value = LiveInput()
    }

    // ---- Equivalencias ----

    fun setMapping(ps: PsButton, xbox: XboxButton) {
        _profile.update { it.withMapping(ps, xbox) }
        repository.saveProfile(_profile.value)
    }

    fun resetMapping() {
        _profile.value = MappingProfile.DEFAULT
        repository.saveProfile(MappingProfile.DEFAULT)
    }

    // ---- Filtro de accesibilidad (opcional) ----

    fun setFilterEnabled(enabled: Boolean) {
        _filter.update { it.copy(enabled = enabled) }
        repository.saveFilter(_filter.value)
    }

    fun toggleBlocked(keyCode: Int) {
        _filter.update {
            it.copy(blockedKeys = if (keyCode in it.blockedKeys) it.blockedKeys - keyCode else it.blockedKeys + keyCode)
        }
        repository.saveFilter(_filter.value)
    }

    // ---- Informe de diagnóstico ----

    fun buildReport(): String = buildString {
        appendLine("PS4 to Xbox Mapper - informe de diagnóstico")
        appendLine("Teléfono: ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        appendLine()
        val list = controllers.value
        if (list.isEmpty()) appendLine("Mandos: ninguno detectado")
        list.forEach { c ->
            appendLine("Mando: ${c.name} [${c.kind.label}] VID %04X PID %04X".format(c.vendorId, c.productId))
            appendLine("  Ejes declarados: ${c.axisNames.joinToString(", ")}")
        }
        appendLine()
        appendLine("Equivalencias modificadas: ${_profile.value.changedCount()}")
        val live = _live.value
        if (live.axes.isNotEmpty()) {
            appendLine("Ejes (último valor):")
            live.axes.toSortedMap().forEach { (axis, v) ->
                appendLine("  ${MotionEvent.axisToString(axis)} = %.2f".format(v))
            }
        }
        appendLine("Últimos botones (más antiguo primero):")
        live.log.asReversed().forEach { r ->
            val t = r.translation
            appendLine(
                "  ${if (r.down) "DOWN" else "UP  "} ${r.keyName} (${r.keyCode})" +
                    (t?.let { " -> ${it.ps.name} -> Xbox ${it.xbox.label}" } ?: " -> no reconocido"),
            )
        }
    }

    private companion object {
        const val MAX_LOG = 40
    }
}
