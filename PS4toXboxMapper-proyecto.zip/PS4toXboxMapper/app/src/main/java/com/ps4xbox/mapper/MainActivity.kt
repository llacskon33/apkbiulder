package com.ps4xbox.mapper

import android.os.Bundle
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.ps4xbox.mapper.ui.AppRoot
import com.ps4xbox.mapper.ui.theme.PS4XboxTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PS4XboxTheme {
                AppRoot(viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshStatus()
    }

    /**
     * Android entrega los botones del mando como KeyEvent a la ventana en primer plano.
     * Aquí los observamos; en el panel de pruebas además se consumen para que no muevan el foco de la UI.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.isFromSource(InputDevice.SOURCE_GAMEPAD) || KeyEvent.isGamepadButton(event.keyCode)) {
            viewModel.onKeyEvent(event)
            if (viewModel.capturing) return true
        }
        return super.dispatchKeyEvent(event)
    }

    /** Sticks, gatillos analógicos y cruceta (HAT) llegan como MotionEvent genéricos. */
    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        if (ev.isFromSource(InputDevice.SOURCE_JOYSTICK) && ev.action == MotionEvent.ACTION_MOVE) {
            viewModel.onMotion(ev)
            if (viewModel.capturing) return true
        }
        return super.dispatchGenericMotionEvent(ev)
    }
}
