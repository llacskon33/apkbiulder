package com.ps4xbox.mapper.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MappingProfileTest {

    @Test
    fun defaultProfileMatchesRequestedTable() {
        val p = MappingProfile.DEFAULT
        assertEquals(XboxButton.A, p.xboxFor(PsButton.CROSS))
        assertEquals(XboxButton.B, p.xboxFor(PsButton.CIRCLE))
        assertEquals(XboxButton.Y, p.xboxFor(PsButton.TRIANGLE))
        assertEquals(XboxButton.X, p.xboxFor(PsButton.SQUARE))
        assertEquals(XboxButton.LB, p.xboxFor(PsButton.L1))
        assertEquals(XboxButton.RB, p.xboxFor(PsButton.R1))
        assertEquals(XboxButton.LT, p.xboxFor(PsButton.L2))
        assertEquals(XboxButton.RT, p.xboxFor(PsButton.R2))
        assertEquals(XboxButton.LS, p.xboxFor(PsButton.L3))
        assertEquals(XboxButton.RS, p.xboxFor(PsButton.R3))
        assertEquals(XboxButton.MENU, p.xboxFor(PsButton.OPTIONS))
        assertEquals(XboxButton.VIEW, p.xboxFor(PsButton.SHARE))
        assertEquals(0, p.changedCount())
    }

    @Test
    fun translateUsesAndroidKeyCodes() {
        val t = MappingProfile.DEFAULT.translate(AndroidKeys.BUTTON_A)!!
        assertEquals(PsButton.CROSS, t.ps)
        assertEquals(XboxButton.A, t.xbox)
        assertEquals(AndroidKeys.BUTTON_A, t.outputKeyCode)
        assertNull(MappingProfile.DEFAULT.translate(9999))
    }

    @Test
    fun editedMappingIsApplied() {
        val p = MappingProfile.DEFAULT.withMapping(PsButton.CROSS, XboxButton.B)
        assertEquals(1, p.changedCount())
        assertEquals(AndroidKeys.BUTTON_B, p.translate(AndroidKeys.BUTTON_A)!!.outputKeyCode)
        assertTrue(p.duplicates().containsKey(XboxButton.B))
    }

    @Test
    fun codecRoundTripAndTolerance() {
        val p = MappingProfile.DEFAULT.withMapping(PsButton.SQUARE, XboxButton.NONE)
        assertEquals(p, MappingCodec.decode(MappingCodec.encode(p)))
        assertEquals(MappingProfile.DEFAULT, MappingCodec.decode(null))
        assertEquals(MappingProfile.DEFAULT, MappingCodec.decode("basura\nFOO=BAR\nCROSS=NOPE"))
    }

    @Test
    fun keyCodesAreUnique() {
        assertEquals(PsButton.entries.size, PsButton.entries.map { it.reportedKeyCode }.toSet().size)
    }
}
