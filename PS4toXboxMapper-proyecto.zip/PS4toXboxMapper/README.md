# PS4 to Xbox Mapper

App Android nativa (Kotlin + Jetpack Compose) para diagnosticar un mando DualShock 4 y gestionar sus equivalencias con el esquema Xbox.

- **minSdk 26**, **targetSdk 33** (Android 13), compileSdk 34. Sin root. Sin permisos en tiempo de ejecución.
- Pensada para un realme C33 (Android 13), por Bluetooth o USB.

> **Estado de verificación (importante):** el paquete `core` (botones, perfiles, serialización) se compiló y se probó con `kotlinc` fuera de Android. **El resto del proyecto (Compose, Activity, servicio) no se ha podido compilar todavía**: el entorno donde se escribió no tiene Android SDK ni acceso a Google Maven. Es posible que la primera compilación muestre algún error menor que habrá que corregir. Tampoco se ha probado con un mando real ni con StarParks.

## Qué hace

| Función | Estado |
|---|---|
| Detectar mandos conectados (InputManager + `InputDeviceListener`), identificar DualShock 4 por VID/PID `054c:05c4` / `09cc` / `0ba0`, mostrar ejes declarados | Implementado |
| Detectar cada botón en tiempo real (`dispatchKeyEvent`) con su código de Android | Implementado |
| Perfil editable PS → Xbox, guardado en el teléfono | Implementado |
| Panel de pruebas: último botón, código, traducción PS→Xbox, sticks, gatillos analógicos, ejes en bruto, historial | Implementado |
| Informe de diagnóstico compartible (modelo de teléfono, mando, ejes, botones recibidos) | Implementado |
| Filtro de botones por servicio de accesibilidad (bloquea botones elegidos) | Implementado, **experimental** |
| Que StarParks reciba otros botones/ejes distintos de los que envía Android | **No es posible sin root** (ver abajo) |

## Qué ocurre realmente en Android (investigación)

1. **Android ya mapea el DualShock 4 al esquema Xbox por posición.** El archivo de teclas oficial de AOSP para el DS4 asigna Cruz→`BUTTON_A`, Círculo→`BUTTON_B`, Cuadrado→`BUTTON_X`, Triángulo→`BUTTON_Y`, SHARE→`BUTTON_SELECT`, OPTIONS→`BUTTON_START`, PS→`BUTTON_MODE`, y L2/R2 como ejes `LTRIGGER`/`RTRIGGER`. Está incluido por defecto desde Android 9. Tu tabla PS→Xbox coincide, por tanto, con lo que Android ya envía.
2. **Una app normal no puede crear un mando virtual global** ni alterar los eventos que recibe otra app. Eso requiere privilegios del sistema o root.
3. **`AccessibilityService`**: con `FLAG_REQUEST_FILTER_KEY_EVENTS` recibe los `KeyEvent` en `onKeyEvent()` y solo puede devolver `true` (consumir) o `false` (dejar pasar). El diseño de AOSP indica explícitamente que no puede inyectar ni modificar los eventos observados. Por eso aquí **no** se usa para remapear, solo para bloquear botones.
4. Sustituir el archivo de teclas del sistema (`.kl`), por ejemplo con módulos de Magisk, requiere root y queda fuera del alcance.

**Alternativa viable implementada:** diagnóstico exacto de lo que envía el mando + informe para el soporte de StarParks + equivalencias aplicadas dentro de la app + filtro de botones. No pude confirmar con documentación oficial cómo gestiona StarParks (paquete `com.cga.cloudgame.platform`, de TATA BOX) los mandos; el panel de pruebas sirve justo para averiguar qué códigos y ejes llegan.

## Compilar

### Opción A: Android Studio
1. Instala Android Studio (Koala o posterior) con JDK 17.
2. `File > Open` y elige la carpeta `PS4toXboxMapper`.
3. Deja que sincronice Gradle (descarga SDK 34 si lo pide).
4. `Build > Build APK(s)`. El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

### Opción B: línea de comandos
Requiere JDK 17 y Android SDK (plataforma 34) con `ANDROID_HOME` definido:
```bash
./gradlew testDebugUnitTest   # pruebas del núcleo
./gradlew assembleDebug       # APK en app/build/outputs/apk/debug/
```

### Opción C: sin Android Studio (GitHub Actions)
1. Sube esta carpeta a un repositorio de GitHub (rama `main`).
2. Ve a la pestaña **Actions > Build APK** (se ejecuta sola al subir, o con *Run workflow*).
3. Al terminar, descarga el artefacto `PS4toXboxMapper-debug-apk` (contiene `app-debug.apk`).

## Instalar en el realme C33
1. Pasa el APK al teléfono y ábrelo; permite «instalar apps desconocidas» para el gestor de archivos o navegador que uses.
2. Empareja el DualShock 4 (mantén PS + SHARE hasta que parpadee) desde Ajustes > Bluetooth, o conéctalo por USB con adaptador OTG.
3. Abre la app: la pantalla de inicio debe mostrar «DualShock 4 conectado».

## Filtro de botones (opcional)
Ajustes > Accesibilidad > *PS4 to Xbox Mapper: filtro de botones*. En Android 13, para APK instalados fuera de Play Store el interruptor puede estar bloqueado: Ajustes > Aplicaciones > PS4 to Xbox Mapper > ⋮ > *Permitir ajustes restringidos*. El servicio no lee la pantalla ni recoge datos; solo consume los botones que marques.

## Estructura
```
app/src/main/java/com/ps4xbox/mapper/
├── core/       Botones PS/Xbox, perfil y serialización (Kotlin puro, con pruebas)
├── data/       Persistencia (SharedPreferences)
├── input/      Detección de mandos y estado en vivo
├── service/    Servicio de accesibilidad (filtro de botones)
├── ui/         Tema oscuro, componentes y pantallas (Inicio, Equivalencias, Pruebas, Ayuda)
├── MainActivity.kt   Recibe KeyEvent / MotionEvent del mando
└── MainViewModel.kt
```

## Notas
- El APK `release` se firma con la clave de depuración para que sea instalable sin keystore propio; no sirve para publicar en Play Store.
- Las flechas de la cruceta de un DS4 llegan como eje HAT (`HAT_X`/`HAT_Y`), y Android también las convierte a eventos `DPAD_*`.
